function n(t,e,r="item"){return`/${r}/${t.encode()}`}function o(t,e){return n(t,e,"article")}export{o as g};
