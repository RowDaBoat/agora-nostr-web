function c(e){return`/packs/${e.encode()}`}export{c as g};
