function e(r){return new Worker(""+new URL("../workers/sig-verify.worker-CgBAHr0O.js",import.meta.url).href,{type:"module",name:r?.name})}export{e as default};
