import{g as t}from"./vjiKTA8K.js";import{t as o}from"./0JNfDbnS.js";function m(...r){return o(t(r))}export{m as c};
