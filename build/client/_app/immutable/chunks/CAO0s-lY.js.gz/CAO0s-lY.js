import{g as t}from"./D1jhUNbu.js";import{c as p}from"./CAJmB2zv.js";function i(n){const o=p.npubEncode(n);t(`/p/${o}`)}function u(n){return`/p/${p.npubEncode(n)}`}export{u as g,i as n};
