import{E as s,a6 as c,i,j as m}from"./-h67YDCL.js";import{B as p}from"./DG6c9x1x.js";function E(n,r,o){i&&m();var e=new p(n);s(()=>{var a=r()??null;e.ensure(a,a&&(t=>o(t,a)))},c)}export{E as c};
